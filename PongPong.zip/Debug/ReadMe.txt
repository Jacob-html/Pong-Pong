Pong Pong

Created by Jacob Barbulescu, Ethan Lu, and Everett Renshaw for the 2022 Zero Robotics (un)official C code-off

Pong Pong is out rendition of Pong within our own, custom game engine coded in C using the SDL2 library.

Tools used for learning ranged from codecademy to Youtube tutorials.

The game itself is classic Pong with the addition of powerups.

How to play-
	2 players face off one another
	Player 1 uses 'w' and 's' to move the left paddle up and down
	Player 2 uses 'up' and 'down' to move the right paddle up and down
	The goal is to have the ball go the edge of the opponent's side of the screen to win points
	The first to 3 points wins!

The Powerups-
	Powerups can change many things, from window size to player speeds! Have the ball hit the glowing cube to get a powerup.

The Music-
	Press 'm' to have the official Pong Pong ost begin playing.
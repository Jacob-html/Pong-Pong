/*
Jacob Barbulescu, Ethan Lu, Everett Renshaw
4-15-22
PongPong.c

This is a game (Pong) meant to demonstrate out group's knowledge in C. It uses the SDL library for graphics/audio.
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include "SDL.h"
#include "SDL_mixer.h"

//structs are many variables stored into one. Speed is pixels per second. typedef and Ball at the end allow us to use this struct without typing struct every time.
typedef struct Ball {
	float x, y, xSpeed, ySpeed;
	int size;
} Ball;

typedef struct Player {
	int score, width, height, playerNum, margin;
	float x, y, speed;
} Player;

typedef struct Powerup {
	float x, y, speed;
	int type, size;
} Powerup;

//These prototypes declare the custom functions without intitializing them. Allows for main to call them. If no parameters, put void as parameter for good practice.
bool setUp(void);

bool loadAudio(void);

void createWindow(Player*, Player*);
void createRenderer(void);

float calculateSpeed(const float);

Ball createBall(void);

Player createPlayer(int);

Powerup createPowerup(void);

void mainGame(void);

void updateBall(Ball*, float);
void renderBall(const Ball*);

void updatePlayer(Player*, float, Uint8*);
void renderPlayer(Player*);

void placePowerup(Powerup*, Player*, Player*);
void updatePowerup(Powerup*, Ball*, Player*, Player*);
void activatePowerup(Powerup*, Ball*, Player*, Player*);
void deactivatePowerup(Powerup*, Ball*, Player*, Player*);

void checkForIntersection(Ball*, Player*, Player*, Powerup*);
void checkForGoal(Ball*, Player*, Player*, Powerup*);

void update(float);

void endRound(Ball*, Player*);

void shutDown(void);

//Icky global variables used to allow for clean functions, but extra care must be taken with them. The NULL is just good practice.
SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;

//Sound vairables. Chunk is for noises, but Music would be used for, well, music.
Mix_Chunk* bounceNoise = NULL;
Mix_Chunk* roundEndNoise = NULL;
Mix_Chunk* powerupNoise = NULL;
Mix_Music* backgroundJam = NULL;

int width = 700, height = 500;

bool served = false;

Ball ball;

Player player1, player2;

Powerup powerup;

int main(int argc, char *argv[]) {
	//When the program exits, this function is ran
	atexit(shutDown);

	//Checks to make sure the start up went well. Otherwise, it quits. The atexit still allows for shutDown to be called.
	if (!setUp()) {
		exit(1);
	}

	mainGame();

	return 0;
}

bool setUp() {
	//This both tries to initiate the SDL library stuff and checks if it was unsuccessful
	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
		//GetError is a string that represents the last error to have happened. fprintf puts the data into a file.
		fprintf(stderr, "Failed to initialize SDL: %s\n", SDL_GetError());

		return false;
	}

	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) != 0) {
		fprintf(stderr, "Failed to initialize mixer: %s\n", Mix_GetError());

		return false;
	}

	if (!loadAudio()) {
		fprintf(stderr, "Failed to load audio: %s\n", Mix_GetError());
	 }

	ball = createBall();

	player1 = createPlayer(1);
	player2 = createPlayer(2);

	powerup = createPowerup();

	createWindow(&player1, &player2);

	//Checks if window is false (NULL)
	if (!window) {
		fprintf(stderr, "Failed to initialize window: %s\n", SDL_GetError());

		return false;
	}

	createRenderer();

	if (!renderer) {
		fprintf(stderr, "Failed to initialize renderer: %s\n", SDL_GetError());

		return false;
	}

	//Seeds the rng
	srand((unsigned int)time(NULL));

	return true;
}

bool loadAudio() {
	//This gives a sound for the variable to hold.
	bounceNoise = Mix_LoadWAV("Audio/Bounce.wav");

	roundEndNoise = Mix_LoadWAV("Audio/RoundEnd.wav");

	powerupNoise = Mix_LoadWAV("Audio/Powerup.wav");

	backgroundJam = Mix_LoadMUS("Audio/breaking-bad-theme-ringtone.wav");

	return bounceNoise && roundEndNoise && powerupNoise && backgroundJam;
}

void createWindow(Player* player1, Player* player2) {
	//Makes sure there are no duplicates
	if (window) {
		SDL_DestroyWindow(window);
	}
	
	char title[16];
	snprintf(title, sizeof(title), "Pong Pong %d | %d", player1->score, player2->score);

	//Creates the window for the game. (Title, x pos, y pos, width, height, special flags). 
	window = SDL_CreateWindow("title", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, width, height, SDL_WINDOW_SHOWN);
}

void createRenderer() {
	if (renderer) {
		SDL_DestroyRenderer(renderer);
	}

	//Creates the renderer for the window. (window, index, flags)
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
}

float calculateSpeed(const float SPEED) {
	//This does a 50/50 random chance to see which directions the ball goes at the start. The whole ? thing says what value each result yields.
	return SPEED * (rand() % 2 == 1 ? 1 : -1);
}

Ball createBall() {
	const float SPEED = 400.0f;
	const int SIZE = 15;

	Ball tempBall = {
		.x = (width / 2) - (SIZE / 2),
		.y = (height / 2) - (SIZE / 2),
		.size = SIZE,

		.xSpeed = calculateSpeed(SPEED),
		.ySpeed = calculateSpeed(SPEED),
	};

	return tempBall;
}

Player createPlayer(int playerNum) {
	const float SPEED = 350.0f;
	const int PLAYERWIDTH = 15, PLAYERHEIGHT = 100, MARGIN = 15;

	Player tempPlayer = {
		.score = 0,
		.width = PLAYERWIDTH,
		.height = PLAYERHEIGHT,
		.margin = MARGIN,
		.x = playerNum == 1 ? MARGIN : width - MARGIN - PLAYERWIDTH,
		.y = (height / 2) - (PLAYERHEIGHT / 2),
		.speed = SPEED,
		.playerNum = playerNum,
	};

	return tempPlayer;
}

Powerup createPowerup() {
	const float SPEED = 50.0f;
	const int SIZE = 50;

	Powerup tempPowerup = {
		.speed = SPEED,
		.size = SIZE,
	};

	return tempPowerup;
}

void mainGame() {
	//Is a check for the game loop to see if the game is over by any means.
	bool isOver = false;

	//event deals with input from the user.
	SDL_Event event;

	//Uint32 guarantess 32 bytes of data for the variable. GetTicks sees how many milliseconds since the SDL library was created.
	Uint32 lastTick = SDL_GetTicks();

	Uint32 currentTick, difference;
	float timeElapsed;

	placePowerup(&powerup, &player1, &player2);

	//Main loop
	while (!isOver) {
		//SDL_PollEvent returns 1 (true) if an event has occured and 0 (false if none have occured). This determines if the event loop fires.
		while (SDL_PollEvent(&event)) {
			//Checks to see if the event was the window closing
			if (event.type == SDL_QUIT) {
				isOver = true;
			}
		}

		//Calculates the amount of time that hass passed between each frame (loop). This regulates game speed at different fps.
		currentTick = SDL_GetTicks();
		difference = currentTick - lastTick;
		timeElapsed = difference / 1000.0f;

		update(timeElapsed);

		//Updates the lastTick to keep difference accurate between each frame.
		lastTick = currentTick;
	}
}

void updateBall(Ball* ball, float timeElapsed) {
	if (!served) {
		ball->x = width / 2;
		ball->y = height / 2;
		return;
	}

	ball->x += ball->xSpeed * timeElapsed;
	ball->y += ball->ySpeed * timeElapsed;

	//Checks if ball goes out of bounds vertically. If so, direction is reversed. This structure prevents ball getting "stuck" back and forth out of bounds.
	if (ball->y < 0) {
		ball->ySpeed = fabs(ball->ySpeed);

		//Plays a noise in a sound channel. (Which channel, which audio clip, how many times to repeat)
		Mix_PlayChannel(-1, bounceNoise, 0);
	}
	if (ball->y + ball->size > height) {
		ball->ySpeed = -fabs(ball->ySpeed);

		Mix_PlayChannel(-1, bounceNoise, 0);
	}
}

void renderBall(const Ball* ball) {
	//The -> is how you acces the variables of a struct
	int halfSize = ball->size / 2;

	//Puts the ball into a rect (x, y, w, h) so it can be rendered by SDL.
	SDL_Rect rectBall = {
		.x = ball->x,
		.y = ball->y,
		.w = ball->size,
		.h = ball->size,
	};

	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);

	//renders the ball, but does NOT update the screen.
	SDL_RenderFillRect(renderer, &rectBall);
}

void updatePlayer(Player* player, float timeElapsed, Uint8* keyboardState) {
	if (player->playerNum == 2) {
		player->x = width - player->margin - player->width;
	}

	//Checks input to see how to move player paddles
	if (keyboardState[player->playerNum == 1 ? SDL_SCANCODE_W : SDL_SCANCODE_UP]) {
		player->y -= player->speed * timeElapsed;
	}
	if (keyboardState[player->playerNum == 1 ? SDL_SCANCODE_S : SDL_SCANCODE_DOWN]) {
		player->y += player->speed * timeElapsed;
	}

	//makes sure player does not go out of bounds
	if (player->y < 0) {
		player->y = 0;
	}
	if (player->y + player->height > height) {
		player->y = height - player->height;
	}


}

void renderPlayer(Player* player) {
	SDL_Rect rectPlayer = {
		.x = player->x,
		.y = player->y,
		.w = player->width,
		.h = player->height,
	};

	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);

	SDL_RenderFillRect(renderer, &rectPlayer);
}

void placePowerup(Powerup* powerup, Player* player1, Player* player2) {
	const int minWidth = player1->margin + player1->width, maxWidth = width - player2->margin - player2->width - powerup->size;

	//Places the powerup in a random spot with a random type
	powerup->x = rand() % (maxWidth + 1 - minWidth) + minWidth;
	powerup->y = rand() % (height - powerup->size + 1);
	powerup->type = rand() % 12;
}

void updatePowerup(Powerup* powerup, Ball* ball, Player* player1, Player* player2, float timeElapsed) {
	if (powerup->y < height) {
		return;
	}

	powerup->y -= powerup->speed * timeElapsed;

	if (powerup->y < height) {
		deactivatePowerup(powerup, ball, player1, player2);

		placePowerup(powerup, player1, player2);
	}
}

void renderPowerup(Powerup* powerup) {
	SDL_Rect rectPowerup = {
		.x = powerup->x,
		.y = powerup->y,
		.w = powerup->size,
		.h = powerup->size,
	};

	SDL_SetRenderDrawColor(renderer, rand()%255, rand()%255, rand()%255, 255);

	SDL_RenderFillRect(renderer, &rectPowerup);
}

void activatePowerup(Powerup* powerup, Ball* ball, Player* player1, Player* player2) {
	powerup->y = height + 500;

	switch (powerup->type) {
	case 0:
		width += 150;
		createWindow(&player1, &player2);
		createRenderer();
		break;
	case 1:
		width -= 150;
		createWindow(&player1, &player2);
		createRenderer();
		break;
	case 2:
		height += 150;
		createWindow(&player1, &player2);
		createRenderer();
		break;
	case 3:
		height -= 150;
		createWindow(&player1, &player2);
		createRenderer();
		break;
	case 4:
		player1->height += 50;
		player2->height += 50;
		break;
	case 5:
		player1->height -= 50;
		player2->height -= 50;
		break;
	case 6:
		player1->speed += 150;
		player2->speed += 150;
		break;
	case 7:
		player1->speed -= 150;
		player2->speed -= 150;
		break;
	case 8:
		ball->size += 10;
		break;
	case 9:
		ball->size -= 10;
		break;
	case 10:
		if (ball->xSpeed > 0) {
			ball->xSpeed += 150;
		}
		else {
			ball->xSpeed -= 150;
		}

		if (ball->ySpeed > 0) {
			ball->ySpeed += 150;
		}
		else {
			ball->ySpeed -= 150;
		}
		break;
	case 11:
		if (ball->xSpeed > 0) {
			ball->xSpeed -= 150;
		}
		else {
			ball->xSpeed += 150;
		}

		if (ball->ySpeed > 0) {
			ball->ySpeed -= 150;
		}
		else {
			ball->ySpeed += 150;
		}
		break;
	}
}

void deactivatePowerup(Powerup* powerup, Ball* ball, Player* player1, Player* player2) {
	switch (powerup->type) {
	case 0:
		width -= 150;
		createWindow(&player1, &player2);
		createRenderer();
		break;
	case 1:
		width += 150;
		createWindow(&player1, &player2);
		createRenderer();
		break;
	case 2:
		height -= 150;
		createWindow(&player1, &player2);
		createRenderer();
		break;
	case 3:
		height += 150;
		createWindow(&player1, &player2);
		createRenderer();
		break;
	case 4:
		player1->height -= 50;
		player2->height -= 50;
		break;
	case 5:
		player1->height += 50;
		player2->height += 50;
		break;
	case 6:
		player1->speed -= 150;
		player2->speed -= 150;
		break;
	case 7:
		player1->speed += 150;
		player2->speed += 150;
		break;
	case 8:
		ball->size -= 10;
		break;
	case 9:
		ball->size += 10;
		break;
	case 10:
		if (ball->xSpeed > 0) {
			ball->xSpeed -= 150;
		}
		else {
			ball->xSpeed += 150;
		}

		if (ball->ySpeed > 0) {
			ball->ySpeed -= 150;
		}
		else {
			ball->ySpeed += 150;
		}
		break;
	case 11:
		if (ball->xSpeed > 0) {
			ball->xSpeed += 150;
		}
		else {
			ball->xSpeed -= 150;
		}

		if (ball->ySpeed > 0) {
			ball->ySpeed += 150;
		}
		else {
			ball->ySpeed -= 150;
		}
		break;
	}
}

void checkForIntersection(Ball* ball, Player* player1, Player* player2, Powerup* powerup) {
	SDL_Rect rectBall = {
		.x = ball->x,
		.y = ball->y,
		.w = ball->size,
		.h = ball->size,
	};

	SDL_Rect rectPlayer1 = {
		.x = player1->x,
		.y = player1->y,
		.w = player1->width,
		.h = player1->height,
	};

	SDL_Rect rectPlayer2 = {
		.x = player2->x,
		.y = player2->y,
		.w = player2->width,
		.h = player2->height,
	};

	SDL_Rect rectPowerup = {
		.x = powerup->x,
		.y = powerup->y,
		.w = powerup->size,
		.h = powerup->size,
	};

	//This checks if two rectangles are intersecting.
	if (SDL_HasIntersection(&rectBall, &rectPlayer1)) {
		ball->xSpeed = fabs(ball->xSpeed);

		Mix_PlayChannel(-1, bounceNoise, 0);
	}
	if (SDL_HasIntersection(&rectBall, &rectPlayer2)) {
		ball->xSpeed = -fabs(ball->xSpeed);

		Mix_PlayChannel(-1, bounceNoise, 0);
	}

	if (SDL_HasIntersection(&rectBall, &rectPowerup)) {
		activatePowerup(powerup, ball, player1, player2);

		Mix_PlayChannel(-1, powerupNoise, 0);
	}
}

void checkForGoal(Ball* ball, Player* player1, Player* player2, Powerup* powerup) {
	if (ball->x < 0) {
		endRound(ball, player2, player1, powerup);
	}
	if (ball->x + ball->size > width) {
		endRound(ball, player1, player2, powerup);
	}

	char title[16];
	snprintf(title, sizeof(title), "Pong Pong %d | %d", player1->score, player2->score);
	SDL_SetWindowTitle(window, title);
}

void update(float timeElapsed) {
	//This holds the value of each key on the keyboard. Stores wether or not the key is pressed down when it is created. NULL says to get every key state.
	const Uint8* keyboardState = SDL_GetKeyboardState(NULL);

	//Waits for space to be pressed for ball to be served
	if (keyboardState[SDL_SCANCODE_SPACE]) {
		served = true;
	}

	//Exits the game if escape is pressed
	if (keyboardState[SDL_SCANCODE_ESCAPE]) {
		exit(0);
	}

	if (keyboardState[SDL_SCANCODE_M]) {
		//If music not playing
		if (Mix_PlayingMusic() == 0)
		{
			//Play the music
			Mix_PlayMusic(backgroundJam, -1);
		}
		//If music is being played
		else
		{
			//If the music is paused
			if (Mix_PausedMusic() == 1)
			{
				//Resume the music
				Mix_ResumeMusic();
			}
			//If the music is playing
			else
			{
				//Pause the music
				Mix_PauseMusic();
			}
		}
	}

	//Sets the color that the renderer draws in. (R, G, B, A)
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

	//Clears (covers) the entire render with the draw colow
	SDL_RenderClear(renderer);

	updateBall(&ball, timeElapsed);
	renderBall(&ball);

	updatePlayer(&player1, timeElapsed, keyboardState);
	renderPlayer(&player1);

	updatePlayer(&player2, timeElapsed, keyboardState);
	renderPlayer(&player2);

	updatePowerup(&powerup, &ball, &player1, &player2, timeElapsed);
	renderPowerup(&powerup);

	checkForIntersection(&ball, &player1, &player2, &powerup);
	checkForGoal(&ball, &player1, &player2, &powerup);

	//Updates the rendering to show changes
	SDL_RenderPresent(renderer);
}

void endRound(Ball* ball, Player* winPlayer, Player* losePlayer, Powerup* powerup) {
	served = false;

	winPlayer->score++;

	ball->xSpeed = calculateSpeed(ball->xSpeed);
	ball->ySpeed = calculateSpeed(ball->ySpeed);

	winPlayer->y = height / 2 - winPlayer->height / 2;
	losePlayer->y = height / 2 - losePlayer->height / 2;

	Mix_PlayChannel(-1, roundEndNoise, 0);

	if (powerup->y > height) {
		deactivatePowerup(powerup, ball, winPlayer, losePlayer);
	}

	placePowerup(powerup, winPlayer, losePlayer);

	if (winPlayer->score == 3) {
		//Pauses the game
		SDL_Delay(1500);

		exit(0);
	}
}

void shutDown(void) {
	Mix_HaltMusic();
	
	Mix_FreeChunk(bounceNoise);
	Mix_FreeChunk(roundEndNoise);
	Mix_FreeChunk(powerupNoise);
	bounceNoise = NULL;
	roundEndNoise = NULL;
	powerupNoise = NULL;

	Mix_FreeMusic(backgroundJam);
	backgroundJam = NULL;

	//This releases the memory used by the window/renderer if it exists. Need to do that kind of stuff in C.
	if (renderer) {
		SDL_DestroyRenderer(renderer);
	}
	if (window) {
		SDL_DestroyWindow(window);
	}

	//Closes down the SDL library stuff
	SDL_Quit();

	Mix_Quit();
}